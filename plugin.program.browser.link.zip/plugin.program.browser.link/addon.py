#!/usr/bin/python
# -*- coding: utf-8 -*-
# ____________________        I M P O R T        ____________________
import xbmc
import xbmcplugin
import xbmcgui
import webbrowser
import sys
import urllib
import ast
from urlparse import parse_qsl

# ____________________     V A R I A B L E S     ____________________

    # ___ Get base_url, add_handle and arguments
__url__ = sys.argv[0]
    # ___ Get the handle integer
__handle__ = int(sys.argv[1])    
    # ___ {<parameter>: <value>} elements
__params__ = dict(parse_qsl(sys.argv[2][1:]))


# ____________________     M E T H O D S     ____________________

def openUrl(url):
    osWin = xbmc.getCondVisibility('system.platform.windows')
    osOsx = xbmc.getCondVisibility('system.platform.osx')
    osLinux = xbmc.getCondVisibility('system.platform.linux')
    osAndroid = xbmc.getCondVisibility('System.Platform.Android') 
    
    if osOsx:    
        # ___ Open the url with the default web browser
        xbmc.executebuiltin("System.Exec(open "+url+")")
    elif osWin:
        # ___ Open the url with the default web browser
        xbmc.executebuiltin("System.Exec(cmd.exe /c start "+url+")")
    elif osLinux and not osAndroid:
        # ___ Need the xdk-utils package
        xbmc.executebuiltin("System.Exec(xdg-open "+url+")") 
    elif osAndroid:
        # ___ Open media with standard android web browser
        xbmc.executebuiltin("StartAndroidActivity(com.android.browser,android.intent.action.VIEW,,"+url+")")
        
        # ___ Open media with Mozilla Firefox
        xbmc.executebuiltin("StartAndroidActivity(org.mozilla.firefox,android.intent.action.VIEW,,"+url+")")                    
        
        # ___ Open media with Chrome
        xbmc.executebuiltin("StartAndroidActivity(com.android.chrome,,,"+url+")") 

def directOpenURL(url):
    """"
        Method to open url
        @param url: the url to open
    """
    webbrowser.open(url)
    
def openFromDialog(urls):
    """
        Method to choose a link with a dialog
    """
    dialog = xbmcgui.Dialog()
    selected = dialog.select('Choose an url', urls)   
    url = urls[selected]
    directOpenURL(url)
    # or
    # openUrl(url)
    

# ____________________    UI   M E T H O D S    ____________________
def initMenu():
    """
        Method to initialize the menu
    """
    xbmcplugin.setContent(__handle__, 'folder')
    
    element1 = {'action': 'dialogList',
               'label': 'Display list with dialog'}
    url1 = __url__ + '?' + urllib.urlencode(element1)
    li1 = xbmcgui.ListItem(element1['label'])
    xbmcplugin.addDirectoryItem(handle=__handle__, 
                                url=url1,
                                listitem=li1, 
                                isFolder=True)
    
    element2 = {'action': 'directList',
               'label': 'Display direct link list'}
    url2 = __url__ + '?' + urllib.urlencode(element2)
    li2 = xbmcgui.ListItem(element2['label'])
    xbmcplugin.addDirectoryItem(handle=__handle__, 
                                url=url2,
                                listitem=li2, 
                                isFolder=True)
    
    xbmcplugin.endOfDirectory(__handle__) 
    

def initDialogList():
    """
        Method to initialize a list of item which open a dialog with our list of url
    """
    xbmcplugin.setContent(__handle__, 'folder')
    
    element1 = {'action': 'dialog',
               'label': 'Element which open a dialog',
               'urls':['http://www.google.fr/', 'http://www.google.com/', 'http://www.google.de/']
               }
    url1 = __url__ + '?' + urllib.urlencode(element1)
    li1 = xbmcgui.ListItem(element1['label'])
    xbmcplugin.addDirectoryItem(handle=__handle__, 
                                url=url1,
                                listitem=li1, 
                                isFolder=True) 
    xbmcplugin.endOfDirectory(__handle__) 
    
    
def initDirectList():
    """
        Method to initialize a list of item which open a directly the url
    """
    xbmcplugin.setContent(__handle__, 'folder')
    
    element1 = {'action': 'direct',
               'label': 'Direct link',
               'url':'http://www.google.com/'}
    url1 = __url__ + '?' + urllib.urlencode(element1)
    li1 = xbmcgui.ListItem(element1['label'])
    xbmcplugin.addDirectoryItem(handle=__handle__, 
                                url=url1,
                                listitem=li1, 
                                isFolder=False) 
    xbmcplugin.endOfDirectory(__handle__) 
    
    
# ____________________   R O U T E R    ____________________    
def router(params):
    ""
    if 'action' in params and params['action'] == 'dialogList':
        initDialogList()
    elif 'action' in params and params['action'] == 'directList':
        initDirectList()
    elif 'action' in params and params['action'] == 'dialog':
        urls = ast.literal_eval(params['urls'])
        openFromDialog(urls)
    elif 'action' in params and params['action'] == 'direct':
        directOpenURL(params['url'])
        # or
        # openUrl(url)    
    else:
        initMenu()


# ___ Route by url
router(__params__) 