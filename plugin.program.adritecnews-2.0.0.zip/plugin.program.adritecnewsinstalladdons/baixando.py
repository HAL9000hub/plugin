# -*- coding: utf-8 -*-
#                 -*- adritecNews -*-                      #
#----------------------------------------------------------#
#  INSTALADOR DE ADD-ONS PARA O KODI XBMC - VERSÃO: 2.0.0  #
#----------------------------------------------------------#
# KODI: GPL https://pt.wikipedia.org/wiki/Kodi             #   
# KODI WIKI: https://kodi.wiki/view/Main_Page              #
# PROGRAMAÇÃO: PYTHON: https://docs.python.org/2/tutorial/ #
# CONTATO: adritec_dados@yahooo.com.br                     #
# CANAL: http://YouTube.com/adritecnews                    # 
# SITE: http://adritecnews.com                             #
#----------------------------------------------------------#
#     TODOS OS DIREITOS RESERVADOS: adritecNews 2018       #
#                                                          #
#      Este trabalho está licenciado sob uma Licença       #
#Creative Commons Atribuição-NãoComercial-SemDerivações 4.0# 
#      Internacional. Para ver uma cópia desta licença,    # 
# visite http://creativecommons.org/licenses/by-nc-nd/4.0/ #
#       'Atribuição-Não-Comercial-SemDerivativos 4.0       # 
#             Internacional (CC BY-NC-ND 4.0)'             #
#----------------------------------------------------------#
#                "ATENÇÃO INTERNAUTAS"                     #
#                                                          #
#       FICA PROIBIDO CÓPIA, MODIFICAÇÃO, DIVULGAÇÃO       #
#                SEM MINHA ALTORIZAÇÃO                     #
#    Add-on desenvolvido para fazer AJUSTES no seu KODI,   #
#   para Inscritos e não inscritos do canal adritec News.  #
#----------------------------------------------------------#
import zlib
import base64
def decode_base64( b64string ):
    decoded_data = base64.b64decode( b64string )
    return zlib.decompress( decoded_data , -15)
def base64_encode( string_val ):
    zlibbed_str = zlib.compress( string_val )
    compressed_string = zlibbed_str[2:-4]
    return base64.b64encode( compressed_string )
	
exec(decode_base64('fVXbbuM2EH22vmJgYGGpVWXZm80WLlwgyfayyK3YphcgCAxKHDmEKVIgpayTX9pP2Lf9sg51sWQ3CQFTw5kzZ4bDIS3yQpsStkmehvXMONeqEdeVaIRCVmuhQm1D+2g90bhURkqRzMPm22kNdlIp8p38JIpMSPQyo3PgrERnhNbYrT2PF9CPZZdD9EEwqdd/GL02aK0feLxWwGj0PxAZ6w18VJnuSWpVdOJmP4jWWJ50GM+rxRtRSlyOb8+uL64/Add8jSaRFd7dnt4xbkSJ6e309O52WgPuWpxB7gBX+Nk6K7TqtZa1/vpq6DNuIn38AMtJU8+ocDtiedRGUMQjlC2ZlHXCduJ5XiqZtZBWttQ515+V1Iz7TcmjX5lKH//6dKELVGiChed2/IDGCq1o55NL/SSIa/ouisH/dzb7CS6Eqraw/fF4dXwUwElRSPwHk3NRTt+9fR/NZuCf/35zeRGCFBuE3zDd6ADO7unUcDp/G8XRbP5+Fh0fwZ8sY0a0XhNv5HHMYJhfCBxtSXNBmVxphW16IgOl6cyLZulGDXnxrHtUlBqkVvH7EwvH43ACkxBoapCEqgrXUH7cKKicply59lq6KXJTy3pQ1CAyWBqBDzjMX7I84QxUEkJiQ8joR9Yl/RawKpJ7rTf+0MiLcBAzaPOvy7ODV3kidbohdPMVT0jOdD8a6YCiL1RpHhewW7lRoElRlVS/XKieGL7rmUmexTFMBwFoHezRpJUxRCMfV101kBNnRlLZswZ7tFPwZ/H8qKafUzPtEW6Swq5sgTXN82mR/+BA4IfhlvfJqGUGfD9DfFAEN7BkFMnv9kh0z0YNKOyAa48GpcUXmeNX9jdYTOti7GNLTTd6V80uw+D1AuaJdTf4TRTPM7g8hW9foGQ5U/e65fv2FTrjBN6A/9wRhg32gBod8d9IJRGcUIuW5zyZWnBUL9YHvifHG6RHm3ziOV+4yXlw8ZBr7lOlQjg+aC1LV0qtXUh6EU+Z2DLFtXsXoygCUtE/AGTsQZsQ2LpihmNrnOzR9Pe6bfnQlSgEDJsAfVDcpliUL94TdxdeZw4OzanUFv19NT0VlVHeaDTaqalNCSxsSq8ySqQHhZIggGHCIvxSp0UPsz8+qwGM63Hg7H2E/wA='))